module.exports=[17873,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Bcity%5D_%5Bservice%5D_page_actions_e6bad31b.js.map