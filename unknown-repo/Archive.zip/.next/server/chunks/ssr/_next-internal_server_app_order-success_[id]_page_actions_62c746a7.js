module.exports=[93522,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_order-success_%5Bid%5D_page_actions_62c746a7.js.map