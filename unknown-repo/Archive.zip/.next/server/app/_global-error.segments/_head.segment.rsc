1:"$Sreact.fragment"
2:I[97367,["/guestello/_next/static/chunks/ff1a16fafef87110.js","/guestello/_next/static/chunks/d2be314c3ece3fbe.js"],"ViewportBoundary"]
3:I[97367,["/guestello/_next/static/chunks/ff1a16fafef87110.js","/guestello/_next/static/chunks/d2be314c3ece3fbe.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/guestello/_next/static/chunks/ff1a16fafef87110.js","/guestello/_next/static/chunks/d2be314c3ece3fbe.js"],"IconMark"]
0:{"buildId":"jdim-z-Mce6p18Nsty9eu","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/guestello/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
