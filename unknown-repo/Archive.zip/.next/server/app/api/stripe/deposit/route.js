var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/stripe/deposit/route.js")
R.c("server/chunks/[root-of-the-server]__b966552c._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_stripe_deposit_route_actions_c0716966.js")
R.m(71240)
module.exports=R.m(71240).exports
