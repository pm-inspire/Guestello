1:"$Sreact.fragment"
2:I[90077,["/guestello/_next/static/chunks/9c7e9f7dd5478fad.js","/guestello/_next/static/chunks/40b022e2e22f1384.js","/guestello/_next/static/chunks/8665eb1d2b4b22b8.js","/guestello/_next/static/chunks/8895b133aa56556a.js","/guestello/_next/static/chunks/c12f3693a8c3c9c0.js","/guestello/_next/static/chunks/e35ca76a6922184c.js","/guestello/_next/static/chunks/195deb57084725c3.js"],"ServiceDetailsClient"]
3:I[97367,["/guestello/_next/static/chunks/ff1a16fafef87110.js","/guestello/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"jdim-z-Mce6p18Nsty9eu","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/guestello/_next/static/chunks/e35ca76a6922184c.js","async":true}],["$","script","script-1",{"src":"/guestello/_next/static/chunks/195deb57084725c3.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
